sprite = Sprite('Stage')
