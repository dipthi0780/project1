import time, random

p = Sprite('Player')
o1 = Sprite('Obstacle')
o2 = Sprite('Obstacle1')
fd = FaceDetection()

fd.video("on", 70)
time.sleep(2)

score = 0
life = 5

p.sety(-150)

obs = [o1, o2]

for o in obs:
    o.sety(random.randint(50, 180))
    o.setx(random.randint(-200, 200))
    o.show()

while True:
    fd.analysecamera()

    if fd.count() > 0:
        target_x = int(float(fd.x(1)))
        p.setx(p.x() + (target_x - p.x()) * 0.3)

    for o in obs:
        o.changey(-10)

        if abs(p.x() - o.x()) < 40 and abs(p.y() - o.y()) < 40:
            life -= 1
            o.sety(180)
            o.setx(random.randint(-200, 200))
            p.say(f"Score {score} | Life {life}", 1)

        elif o.y() < -180:
            score += 1
            o.sety(180)
            o.setx(random.randint(-200, 200))
            p.say(f"Score {score} | Life {life}", 1)

    if life <= 0:
        p.say(f"Game Over! Final Score: {score}", 3)
        break
